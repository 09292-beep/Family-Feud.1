Family Feud ICT Android starter project.
Includes 5 placeholder questions per level (Easy, Medium, Hard), scoring 1/2/3 points per correct answer, local leaderboard, and Firebase placeholders for shared online leaderboard.
Replace question text/choices/correct index in app/src/main/assets/index.html.
For GitHub Actions, upload this ZIP to repository root as FamilyFeudAndroid_Project.zip and create workflow .github/workflows/build-apk.yml using included file. Workflow extracts and builds APK artifact.
